export default {
  i18n: {
    defaultLocale: 'en',
    locales: ['en', 'ro'],
  },
};
