export default function Home() {
  return <h1>Swaply SQLite3 version</h1>
}