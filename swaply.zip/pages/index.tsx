import UploadForm from '../components/UploadForm';

export default function Home() {
  return (
    <div>
      <h1>Swaply – Test Cloudinary Upload</h1>
      <UploadForm />
    </div>
  );
}
